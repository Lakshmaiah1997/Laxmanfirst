﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApplication2.DBContext;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    
    public class CSCLController : ApiController
    {
        IblelaxmanEntities db = new IblelaxmanEntities();
        public IHttpActionResult Get()
        {
            List<Country> lcountry = db.Countries.ToList();
            List<State> lstate=db.States.ToList();
            List<City> lcity=db.Cities.ToList();
            List<Location> llocations=db.Locations.ToList();
            var query = from c in lcountry
                        join st in lstate
                        on c.Cid equals st.Cid
                        
                        join ct in lcity 
                        on st.Sid equals ct.Sid 
                        
                        join lo in llocations on
                        ct.Ctyid equals lo.Ctyid 
                        
                        select new 
                        {
                            GetCountry = c.Cname,
                            GetState = st.Sname,
                            GetCity = ct.Ctyname,
                            GetLocation =lo.Locname
                        };
            return Ok(query);

        }
        
    }
}
