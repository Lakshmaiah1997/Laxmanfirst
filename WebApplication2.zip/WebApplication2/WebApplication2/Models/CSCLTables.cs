﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication2.DBContext;

namespace WebApplication2.Models
{
    public class CSCLTables
    {
        public Country GetCountry { get; set; }
        public State GetState { get; set; }
        public City GetCity { get; set; }
        public Location GetLocation { get; set; }
    }
}